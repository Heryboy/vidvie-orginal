<?php
// Heading
$_['heading_title'] = 'Choose a Store';

// Text
$_['text_default']  = 'Default';
$_['text_store']    = 'Please choose the store you wish to visit.';