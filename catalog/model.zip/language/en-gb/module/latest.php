<?php

// Heading

$_['heading_title'] = 'NEW ARRIVAL';



// Text

$_['text_tax']      = 'Ex Tax:';