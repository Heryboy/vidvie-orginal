<?php
// Text
$_['text_footer'] 	= '<a target="_blank" href="http://www.khmergecko.com">Khmer Gecko</a> &copy; 2016-' . date('Y') . ' All Rights Reserved.';
$_['text_version'] 	= 'Version %s';